/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

/**
 *
 * @author Julian
 */
public class TryDB {
    public int ich = 5;
}
